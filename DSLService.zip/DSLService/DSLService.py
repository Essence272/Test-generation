from textx import metamodel_from_file
from attacktree import  attacker
import json
from flask import Flask
from flask import request

app =Flask(__name__)
def parsetree(tree):
    array=[]
    treenodes=tree.treenodes
    for treenode in treenodes:
        nodetype=treenode.type
        node=treenode.type.__class__.__name__
        print()
        json={}
        if node=='AttackNode':
            metaattack=nodetype.metaattack
            parent = nodetype.goal
            description = nodetype.description
            json={'NodeName': metaattack,'NodeType':node,'Parent':parent,'Operator':None,
                  'description':description}
        elif node=='RootNode':
            threat=nodetype.threat
            description = nodetype.description
            operator = nodetype.operator
            json = {'NodeName': threat, 'NodeType': node, 'Parent': 'main', 'Operator': operator,
                    'description': description}
        elif node=='AttackStateNode':
            attackstate = nodetype.attackstate
            description = nodetype.description
            operator = nodetype.operator
            parent= nodetype.goal
            json = {'NodeName': attackstate, 'NodeType': node, 'Parent':parent, 'Operator': operator,
                    'description': description}
        elif node=='DefenseNode':
            defense=nodetype.defense
            description=nodetype.description
            json = {'NodeName': defense, 'NodeType': node, 'Parent': None, 'Operator': None,
                    'description': description}
        array.append(json)
        print(json)
    print(array)
    return array
@app.route("/", methods=["POST"])
def DSL_to_JSONArray():
    text = request.json['text']
    file = open('lib/CAPEC-63.tx')
    text = file.read()
    file.close()
    # 解析
    tree = attacker.model_from_str(text)
    jsonarry= parsetree(tree)
    return jsonarry
app.run(host='0.0.0.0',port=12347)



