from __future__ import unicode_literals
from textx import metamodel_from_file
from textx.exceptions import TextXSyntaxError
from textx.registration import metamodel_for_language
from pytest import raises
from textx import get_children_of_type
import time
class AttackTree(object):
    def __init__(self,**kwargs):
        self.treenodes = kwargs.pop('treenodes')

class TreeNode(object):
    def __init__(self, **kwargs):
        self.type = kwargs.pop('nodetype')

class RootNode(object):
    def __init__(self,**kwargs):
        self.threat = kwargs.pop('threat')
        self.operator = kwargs.pop('operator')
        self.description = kwargs.pop('info')

class AttackStateNode(object):
    def __init__(self,**kwargs):
        self.attackstate=kwargs.pop('attackstate')
        self.parent=kwargs.pop('goal')
        self.operator = kwargs.pop('operator')
        self.description = kwargs.pop('info')

class AttackNode(object):
    def  __init__(self,**kwargs):
        self.metaattack=kwargs.pop('metaattack')
        self.parent = kwargs.pop('goal')
        self.description = kwargs.pop('info')

class DefenseNode(object):
    def __init__(self,**kwargs):
        self.defense=kwargs.pop('defense')
        self.description = kwargs.pop('info')

def parsetree(tree):
    array=[]
    treenodes=tree.treenodes
    for treenode in treenodes:
        nodetype=treenode.type
        node=treenode.type.__class__.__name__
        json={}
        if node=='AttackNode':
            metaattack=nodetype.metaattack
            parent = nodetype.goal
            description = nodetype.info
            json={'NodeName': metaattack,'NodeType':node,'Parent':parent,'Operator':None,
                  'description':description}
        elif node=='RootNode':
            print('1')
            threat=nodetype.threat
            description = nodetype.info
            operator = nodetype.operator
            json = {'NodeName': threat, 'NodeType': node, 'Parent': 'main', 'Operator': operator,
                    'description': description}
        elif node=='AttackStateNode':
            attackstate = nodetype.attackstate
            description = nodetype.info
            operator = nodetype.operator
            parent= nodetype.goal
            json = {'NodeName': attackstate, 'NodeType': node, 'Parent':parent, 'Operator': operator,
                    'description': description}
        elif node=='DefenseNode':
            defense=nodetype.defense
            description=nodetype.info
            json = {'NodeName': defense, 'NodeType': node, 'Parent': None, 'Operator': None,
                    'description': description}
        array.append(json)
        print(json)
    return array

def grammar_check():
    mm = metamodel_for_language('textx')
    grammar_model = mm.grammar_model_from_file('tt.tx')
    assert len(grammar_model.imports_or_references) == 3
    assert len(grammar_model.rules) == 45

    str_matches = get_children_of_type("SimpleMatch", grammar_model)
def run():
    attacker = metamodel_from_file('tt.tx',classes=[AttackTree,TreeNode,RootNode,AttackStateNode,AttackNode,DefenseNode])
#读取文件
    file = open('lib/CAPEC-126.att')
    text = file.read()
    file.close()
    tree = attacker.model_from_str(text)
    jsonarry = parsetree(tree)


start = time.perf_counter()
run()
end = time.perf_counter()
time = end - start
print('运行时间为：{}秒'.format(end-start))