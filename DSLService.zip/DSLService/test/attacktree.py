from __future__ import unicode_literals
from textx import metamodel_from_file

class AttackTree(object):
    def __init__(self,**kwargs):
        self.subnodes = kwargs.pop('treenodes')

class RootNode(object):
    def __init__(self,**kwargs):
        self.threat = kwargs.pop('threat')
        self.subnodes=kwargs.pop('rn_subnodes')
        self.operator = kwargs.pop('rn_operator')
        self.description = kwargs.pop('rn_info')

class AttackStateNode(object):
    def __init__(self,**kwargs):
        self.attackstate=kwargs.pop('attackstate')
        self.subnodes=kwargs.pop('asn_subnodes')
        self.goal=kwargs.pop('asn_goal')
        self.operator = kwargs.pop('asn_operator')
        self.description = kwargs.pop('asn_info')

class AttackNode(object):
    def  __init__(self,**kwargs):
        self.metaattack=kwargs.pop('metaattack')
        self.goal = kwargs.pop('an_goal')
        self.description = kwargs.pop('an_info')

class DefenseNode(object):
    def __init__(self,**kwargs):
        self.defense=kwargs.pop('defense')
        self.description = kwargs.pop('dn_info')
def parsenode(treenodes):
    array=[]
    for treenode in treenodes:
        node=treenode.__class__.__name__
        json={}
        if node=='AttackNode':
            metaattack=treenode.metaattack
            parent = treenode.goal
            description = treenode.description
            json={'NodeName': metaattack,'NodeType':node,'Parent':parent,'Operator':None,
                  'description':description}
        elif node=='RootNode':
            if treenode.subnodes != None:
                for subnode in treenode.subnodes:
                    subarray = parsetree(subnode)
                    array.append(subarray)
            threat=treenode.threat
            description = treenode.description
            operator = treenode.operator
            json = {'NodeName': threat, 'NodeType': node, 'Parent': 'main', 'Operator': operator,
                    'description': description}
        elif node=='AttackStateNode':
            if treenode.subnodes != None:
                for subnode in treenode.subnodes:
                    subarray = parsetree(subnode)
                    array.append(subarray)
            attackstate = treenode.attackstate
            description = treenode.description
            operator = treenode.operator
            parent= treenode.goal
            json = {'NodeName': attackstate, 'NodeType': node, 'Parent':parent, 'Operator': operator,
                    'description': description}
        elif node=='DefenseNode':
            defense=treenode.defense
            description=treenode.description
            json = {'NodeName': defense, 'NodeType': node, 'Parent': None, 'Operator': None,
                    'description': description}
        array.append(json)
        print(json)
    return array

def parsetree(tree):
    array=[]
    treenodes=tree.subnodes
    for treenode in treenodes:
        node=treenode.__class__.__name__
        json={}
        if node=='AttackNode':
            metaattack=treenode.metaattack
            parent = treenode.goal
            description = treenode.description
            json={'NodeName': metaattack,'NodeType':node,'Parent':parent,'Operator':None,
                  'description':description}
        elif node=='RootNode':
            if treenode.subnodes != None:
                subarray=parsenode(treenode.subnodes)
                array.append(subarray)
            threat=treenode.threat
            description = treenode.description
            operator = treenode.operator
            json = {'NodeName': threat, 'NodeType': node, 'Parent': 'main', 'Operator': operator,
                    'description': description}
        elif node=='AttackStateNode':
            if treenode.subnodes != None:
                subarray = parsenode(treenode.subnodes)
                array.append(subarray)
            attackstate = treenode.attackstate
            description = treenode.description
            operator = treenode.operator
            parent= treenode.goal
            json = {'NodeName': attackstate, 'NodeType': node, 'Parent':parent, 'Operator': operator,
                    'description': description}
        elif node=='DefenseNode':
            defense=treenode.defense
            description=treenode.description
            json = {'NodeName': defense, 'NodeType': node, 'Parent': None, 'Operator': None,
                    'description': description}
        array.append(json)
        print(json)
    print(array)
    return array
attacker = metamodel_from_file('tt.tx',classes=[AttackTree,RootNode,AttackStateNode,AttackNode,DefenseNode])
#读取文件
file = open('CAPEC-126.att')
text = file.read()
file.close()

tree = attacker.model_from_str(text)
jsonarry = parsetree(tree)
#模型解释器，将实例化的模型转化为TreeNode集合