from behave import When,Given,Then
from zapv2 import ZAPv2
from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.common.by import By
import time
import random
class Config:
    def __init__(self,user=None,pwd=None,zap_host=None,zap_port=None,logintarget=None):
        if user!=None:
            self.user=user
        else:
            self.user='user'
        if pwd!=None:
            self.pwd=pwd
        else:
            self.pwd='123456'
        if zap_host!=None:
            self.zap_host=zap_host
        else:
            self.zap_host='127.0.0.1'
        if zap_port!=None:
            self.zap_port=zap_port
        else:
            self.zap_port='8080'
        if logintarget !=None:
            self.logintarget = logintarget
        else:
            self.logintarget = 'http://192.168.0.101/wp-login.php'

config = Config()

def createDriver():
    options=set_options()
    driver = webdriver.Chrome(chrome_options=options)
    return driver

def set_options():
    options=webdriver.ChromeOptions()
    options.add_argument('ignore-certificate-errors')
    options.add_argument('--proxy-server=%s' % config.zap_host + ":" + config.zap_port)
    return options

@Given("初始化webdriver")
def init_driver(context):
    context.driver=createDriver()

@Given("打开登录页面")
def open_login(context):
    assert context.driver != None
    context.driver.get('http://192.168.0.101')
    context.driver.get(config.logintarget)
    time.sleep(5)

@Given("用户登录")
def user_login(context):
    assert context.driver != None
    context.driver.add_cookie({'name':'wordpress_test_cookie','value':'WP+Cookie+check'})
    context.driver.find_element(By.ID, 'user_login').send_keys(config.user)
    context.driver.find_element(By.ID, 'user_pass').send_keys(config.pwd)
    context.driver.find_element(By.ID, 'wp-submit').click()
    context.driver.get('http://192.168.0.101/wp-admin/post.php?post=1&action=edit')
    context.driver.find_element(By.TAG_NAME, 'p').send_keys(str(random))
    context.driver.find_element(By.XPATH, '//button[contains(.,\'更新\')]').click()
    time.sleep(5)
@Then("结束")
def close_driver(context):
    context.driver.quit()

def find_cookie_by_name(cookies,name):
    if len(cookies) ==0:
        return None
    for cookie in cookies:
        if cookie['name'] == name:
            return cookie['value']
    return None




