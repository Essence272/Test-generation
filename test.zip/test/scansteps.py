from behave import When,Given,Then
from zapv2 import ZAPv2
import time
import requests
apikey='9kk6ihe98mhh07bd5pj39r8bb'
target="http://172.21.21.172/"

@Given("使用爬虫遍历")
def spider(context):
    assert context.zap != None
    scanid = context.zap.spider.scan(context.target)
    status = context.zap.spider.status(scanid)
    time.sleep(2)
    while (int(status) < 100):
        status = int(context.zap.spider.status(scanid))
        print('Spider progress %: {}'.format(status))
        time.sleep(2)
    context.spiderid=scanid

@Given("使用ajax爬虫遍历")
def ajaxspider(context):
    assert context.zap != None
    scanid = context.zap.ajaxSpider.scan(context.target)
    status = context.zap.ajaxSpider.status()
    time.sleep(2)
    while (int(status) < 100):
        status = int(context.zap.ajaxSpider.status())
        print('Spider progress %: {}'.format(status))
        time.sleep(2)
    context.ajaxspierid = scanid

@Then("查看爬虫结果")
def spider_result(context):
    assert context.spiderid != None
    results=context.zap.spider.results(context.spiderid)
    for res in results:
        print(context.target+":"+res)

@Then("查看ajax爬虫结果")
def ajaxspider_result(context):
    assert context.ajaxspiderid != None
    results=context.zap.ajaxSpider.results(context.ajaxspiderid)
    for res in results:
        print(context.target+":"+res)

@Given("初始化1")
def initzap(context):
    apikey = '9kk6ihe98mhh07bd5pj39r8bb'
    zap = ZAPv2(apikey=apikey)
    zap.ascan.disable_all_scanners()
    context.zap=zap
    context.target=target

@Given("执行所有攻击")
def scan_all(context):
    context.zap.ascan.enable_all_scanners()

@When("执行{name}攻击")
def scan(context,name):
    scan_id=0
    if name == "XSS":
        scan_id='40012,40014,40016,40017'
    elif name=="sql注入":
        scan_id='40018'
    elif name=="路径遍历":
        scan_id='6'
    elif name == "命令注入":
        scan_id='90020'
    elif name == "LDAP注入":
        scan_id='40015'
    elif name == "XPath注入":
        scan_id="90021"
    context.zap.ascan.enable_scanners(scan_id)
    context.ascanid=scan_id

@When("攻击强度为{strength}")
def set_strength(context,strength):
    assert context.ascanid != None
    context.zap.ascan.set_scanner_attack_strength(context.ascanid,strength)

@When("报警值为{threshold}")
def set_threshold(context,threshold):
    assert context.ascanid != None
    context.zap.ascan.set_policy_alert_threshold(context.ascanid, threshold)

@Then("执行扫描")
def scan(context):
    assert context.zap!=None
    assert context.target != None
    context.zap.alert.delete_all_alerts()
    if context.ascanid !=None:
        runid = context.zap.ascan.scan(context.target,scanpolicyname=context.ascanid)
    else :
        runid = context.zap.ascan.scan(context.target)
    status= 0
    while (status < 100):
        status = int(context.zap.ascan.status(runid))
        print('Scan progress %: {}'.format(status))
        time.sleep(5)

@Given("删除警报")
def deletealerts(context):
    assert context.zap != None
    context.zapalert.alert.delete_all_alerts()

@Then("查看结果")
def view_alerts(context):
    assert context.zap != None
    print('警报数量为:',context.zap.alert.number_of_alerts())
    print(context.zap.alert.alerts())
    print(context.zap.alert.alerts_summary())

