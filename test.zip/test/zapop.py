from zapv2 import ZAPv2
import json
from http.server import BaseHTTPRequestHandler
import email
import io
import requests
import re

def zap_get_http_byid(zap,id,param):
    msg = zap.core.message(id)
    #rtt responseBody responseHeader cookieParams requestBody requestHeader
    return msg[param]

def zap_get_http_byurl(zap,url,param):
    msg = zap.core.messages(url)
    msgs={}
    for m in msg:
        msgs[m['id']]=m[param]
    #rtt responseBody responseHeader cookieParams requestBody requestHeader
    return msgs

def get_request_header_byid(zap,id):
    request_header=zap_get_http_byid(zap,id,'requestHeader')
    return request_header

def get_request_body_byid(zap,id):
    request_body=zap_get_http_byid(zap,id,'requestBody')
    return request_body

def get_request_header_byurl(zap,url,id=None):
    request_header=""
    request_headers=zap_get_http_byurl(zap,url,'requestHeader')
    if id==None:
        key=max(request_headers.keys())
        request_header = request_headers[key]
    else:
        request_header=request_headers[str(id)]
    return request_header

def get_request_body_byurl(zap,url,id=None):
    request_body=""
    request_bodys=zap_get_http_byurl(zap,url,'requestBody')
    if id==None:
        key=max(request_bodys.keys())
        request_body = request_bodys[key]
    else:
        request_body=request_bodys[str(id)]
    return request_body

def get_response_header_byid(zap,id):
    response_header=zap_get_http_byid(zap,id,'responseHeader')
    return response_header

def get_response_body_byid(zap,id):
    response_body=zap_get_http_byid(zap,id,'responseBody')
    return response_body

def get_response_header_byurl(zap,url,id=None):
    response_header=""
    response_headers=zap_get_http_byurl(zap,url,'responseHeader')
    if id==None:
        key=max(response_headers.keys())
        request_header = response_headers[key]
    else:
        request_header=response_headers[id]
    return request_header

def get_response_body_byurl(zap,url,id=None):
    response_body=""
    response_bodys=zap_get_http_byurl(zap,url,'responseBody')
    if id==None:
        key=max(response_bodys.keys())
        request_body = response_bodys[key]
    else:
        request_body=response_bodys[id]
    return request_body

def get_request_byurl(zap,url,id=None):
    header=get_request_header_byurl(zap,url,id)
    body=get_request_body_byurl(zap,url,id)
    request={}
    request['header']=header
    request['body']=body
    return request

def get_response_by_url(zap,url,id=None):
    header=get_response_header_byurl(zap,url,id)
    body=get_response_body_byurl(zap,url,id)
    response={}
    response['header']=header
    response['body'] = body
    return response

def get_response_by_id(zap,id):
    header=get_response_header_byid(zap,id)
    body=get_response_body_byid(zap,id)
    response={}
    response['header']=header
    response['body'] = body
    return response

def set_param(request,param,value,t=None):
    header=request['header']
    body=request['body']
    header=parse_header(header)
    body=parse_body(body)
    if header.get(param)!=None:
        header[param]=value
    elif body.get(param)!=None:
        body[param]=value
    else :
        return None
    res={}
    res['header']=header
    res['body'] =body
    return res

def parse_header(header):
    header=header.split('\r\n', 1)
    request_line, headers_alone = header
    message = email.message_from_file(io.StringIO(headers_alone))
    headers = dict(message.items())
    item=""
    flag=1
    for i in header[0]:
        if i==" ":
            if flag==1:
                headers['method']=item
                item=""
                flag+=1
            elif flag==2:
                headers['url']=item
                item=""
        else:
            item+=i
    headers['http']=item
    return headers

def parse_body(body):
    res={}
    temp=""
    tempvalue=""
    j=json.loads(body)
    return j
    # flag=True
    # for ch in body:
    #     if ch=='&':
    #         res[temp]=tempvalue
    #         temp=""
    #         tempvalue=""
    #     elif ch=='=':
    #         flag=False
    #     elif flag:
    #         temp+=ch
    #     else:
    #         tempvalue+=ch
    # res[temp]=tempvalue
    # return res

def header_to_string(header):
    headline=header["method"]+' '+header['url']+' '+header['http']+'\r\n'
    head=""
    keys = header.keys()
    for key in keys:
        if key != "http" and key != "method" and key!="url":
            head+=key+':'+header[key]+'\r\n'
    headline+=head
    return headline
def body_to_string(body):
    res=json.dumps(body)
    # keys = body.keys()
    # flag=0
    # for key in keys:
    #     if key==' ' or key=="" or key ==None:
    #         break
    #     if flag!=0:
    #         res+='&'
    #     res+=key+'='+body[key]
    #     flag+=1

    return res
def send_request(zap,request):
    header=request['header']
    body = request['body']
    header=header_to_string(header)
    body=body_to_string(body)
    re=header
    if body != None:
        re+='\r\n'+'\r\n' +body
    response=zap.core.send_request(re)
    return response

# apikey='9kk6ihe98mhh07bd5pj39r8bb' # Change to match the API key set in ZAP, or use None if the API key is disabled
# url="http://www.baidu.com"
# zap = ZAPv2(apikey=apikey)
# zap.urlopen(url)
# request=get_request_byurl(zap,url,1)
# request=set_param(request,'Connection','close')
# send_request(zap,request)
#
# print(request['header'],request['body'])
apikey='9kk6ihe98mhh07bd5pj39r8bb'
zap = ZAPv2(apikey=apikey)
# xss_probe='v3dm0s'
    #request在哪注入探针
# zap.urlopen("http://192.168.9.105:80")
url = '192.168.9.105:80'
# step2:login
session = requests.session()
login_url = "http://{}/login.php".format(url)
req = session.get(login_url)
match = re.search(r'([a-z,0-9]){32}', req.text)
token = match.group(0)
data = {'username': 'admin', 'password': 'password', 'Login': 'Login', 'user_token': token}
print(token)
login = session.post(login_url, data=data)
if "Welcome" in login.text:
    print("login successful")
# request=get_request_byurl(zap,'http://192.168.0.100/wp-json/wp/v2/posts/1?_locale=user',1830)
# request = set_param(request, 'content', xss_probe)
# print(request)
#
# response=send_request(zap,request)
# print(response)