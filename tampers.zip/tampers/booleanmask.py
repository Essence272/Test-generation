import re


example = "' AND 1=1 OR 2=2 '"


def booleanmask(payload, **kwargs):
    return re.sub(r"(?i)and", "%26%26", re.sub(r"(?i)or", "%7C%7C", payload))
print(booleanmask(example))