import base64


example = "<script>alert(\"xss\");</script>"
__type__ = "encoding the payload into its base64 equivalent"


def base64encode(payload, **kwargs):
    try:
        payload = str(payload)
        return str(base64.b64encode(payload))
    except TypeError:
        payload = payload.encode("utf-8")
        return base64.b64encode(payload).decode("ascii")

print(base64encode(example))