import socket
import sys
import threading
import json
import torch
import numpy as np
from torch.utils.data import DataLoader
from test import run
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification, DistilBertConfig

Attackvector=['NETWORK','LOCAL','PHYSICAL','ADJACENT_NETWORK']
Attackcomplexity=['LOW','HIGH']
Privilegereq=['NONE','LOW','HIGH']
Userinteraction=['NONE','REQUIRED']
Scope=['UNCHANGED','CHANGED']
Confidentiality=['NONE','LOW','HIGH']
Integrity=['NONE','LOW','HIGH']
Availability=['NONE','LOW','HIGH']


model = {'attackcomplexity':None,'attackvector':None,'privilegereq':None}
tokenizer = DistilBertTokenizerFast.from_pretrained('distilbert-base-cased')
device = torch.device('cpu')
batch_size = 1

class cvssdata(torch.utils.data.Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.labels)

def real_indicator(indicator,pre):
    if indicator == 'attackvector':
        real_indicator = Attackvector[pre]
    elif indicator == 'attackcomplexity':
        real_indicator = Attackcomplexity[pre]
    elif indicator == 'privilegereq':
        real_indicator = Privilegereq[pre]
    elif indicator == 'userinteraction':
        real_indicator = Userinteraction[pre]
    elif indicator == 'scope':
        real_indicator = Scope[pre]
    elif indicator == 'confidentiality':
        real_indicator = Confidentiality[pre]
    elif indicator == 'integrity':
        real_indicator = Integrity[pre]
    elif indicator == 'availability':
        real_indicator = Availability[pre]
    return real_indicator

def select_model(config_path):
    config = DistilBertConfig.from_pretrained(config_path)
    mode = DistilBertForSequenceClassification(config)
    number_tokens = len(tokenizer)
    mode.resize_token_embeddings(number_tokens)
    return mode

def load_models():
    print('模型加载中...')
    for key in model.keys():
        root_dir = 'models/' + key + '/'
        model_path = root_dir + 'pytorch_model.bin'
        config_path = root_dir + 'config.json'
        mode = select_model(config_path)
        checkpoint = torch.load(model_path, map_location=torch.device('cpu'))
        mode.load_state_dict(checkpoint)
        mode.to(device)
        mode.eval()
        model[key] = mode

def predict(text,indicator,modeld):
    text=[text]

    #参数编码
    test_encodings = tokenizer(text, truncation=True, padding=True)
    test_labels=[0]
    cvssdataset = cvssdata(test_encodings,test_labels)
    test_loader=DataLoader(cvssdataset,batch_size=batch_size)

    pre = []
    for batch in test_loader:
        input_ids = batch['input_ids'].to(device)
        attention_mask = batch['attention_mask'].to(device)
        labels = batch['labels'].to(device)

        outputs = modeld(input_ids, attention_mask=attention_mask, labels=labels)
        soft = torch.nn.Softmax(dim=1)
        output_logits = soft(outputs.logits)
        pre.append(output_logits.cpu().detach().numpy())
        print(output_logits)

    pre=np.concatenate(pre,axis=0)
    pre=pre.argmax(axis=1)
    return real_indicator(indicator,pre[0])

def main():
    load_models()
    print("端口启动中...")
    serversocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    host = socket.gethostname()
    port = 12345

    serversocket.bind((host,port))

    serversocket.listen(5)

    myaddr = serversocket.getsockname()
    print("启动成功！")
    while True:
        clientsocket, addr = serversocket.accept()
        try:
            t = ServerThreading(clientsocket)
            t.start()
            pass
        except Exception as e:
            print(e)
            serversocket.close()
            pass
    serversocket.close()

class ServerThreading(threading.Thread):
    def __init__(self,clientsocket,recvsize=1024*1024,encoding="utf-8"):
        threading.Thread.__init__(self)
        self._socket = clientsocket
        self._recvsize = recvsize
        self._encoding = encoding
        pass

    def run(self):
        print("开始预测...")
        try:
            msg = ''
            while True:
                rec = self._socket.recv(self._recvsize)
                msg += rec.decode(self._encoding)
                if msg.strip().endswith('over'):
                    msg = msg[:-4]
                    break
            ret = json.loads(msg)

            text = ret['text']
            indicator = ret['indicator']
            res = predict(text,indicator,model[indicator])

            self._socket.send(("%s" % res).encode(self._encoding))
            pass
        except Exception as e:
            self._socket.send("error".encode(self._encoding))
            print(e)
            pass
        finally:
            self._socket.close()
        pass

main()